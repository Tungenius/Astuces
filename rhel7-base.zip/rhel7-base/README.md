rhel7-base
==================

## Repository de référence
https://access.redhat.com/containers/?tab=overview#/registry.access.redhat.com/rhel
